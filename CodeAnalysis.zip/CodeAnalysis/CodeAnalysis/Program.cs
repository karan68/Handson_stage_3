﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeAnalysis
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 10;
        }
    }
}
