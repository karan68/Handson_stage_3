﻿using System;

namespace AFactory
{
    class MercedesTire : Tire
    {
        public override string ToString()
        {
            Console.WriteLine("Mercedes Tire");
            return "Mercedes Validated";

        }
    }
}
