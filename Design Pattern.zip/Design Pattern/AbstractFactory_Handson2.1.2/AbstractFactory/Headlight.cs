﻿using System;

namespace AFactory
{
    abstract class Headlight
    {
    }
}
