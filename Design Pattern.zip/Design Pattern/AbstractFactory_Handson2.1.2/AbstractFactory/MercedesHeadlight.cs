﻿using System;

namespace AFactory
{
    class MercedesHeadlight : Headlight
    {
        public override string ToString()
        {
       
            return "Mercedes Headlight";
        }
    }
}
