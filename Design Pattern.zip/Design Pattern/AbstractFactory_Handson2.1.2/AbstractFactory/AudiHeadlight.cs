﻿using System;

namespace AFactory
{
    class AudiHeadlight : Headlight
    {
        public override string ToString()
        {
            return "Audi Headlight";
        }
    }
}
