﻿using System;

namespace AFactory
{
    abstract class Tire
    {
    }
}
