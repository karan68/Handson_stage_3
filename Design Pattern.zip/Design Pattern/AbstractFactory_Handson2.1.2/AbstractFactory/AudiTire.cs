﻿using System;

namespace AFactory
{
    class AudiTire : Tire
    {
        public override string ToString()
        {
            Console.WriteLine("Audi Tire");
            return "Audi Validated";
        }
    }
}
