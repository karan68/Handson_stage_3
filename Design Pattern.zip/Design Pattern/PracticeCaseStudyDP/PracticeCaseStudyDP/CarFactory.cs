﻿namespace PracticeCaseStudyDP
{
    public abstract class CarFactory
    {
        public abstract Car BuildCar(CarType carType);
    }
}
