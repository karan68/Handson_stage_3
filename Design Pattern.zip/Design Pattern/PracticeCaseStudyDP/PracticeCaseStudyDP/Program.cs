﻿using System;

namespace PracticeCaseStudyDP
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            CarFactory factory = new IndiaCarFactory();
            CarClient client = new CarClient(factory);
            client.BuildMicroCar(Location.USA);
            client.BuildMiniCar(Location.INDIA);
            client.BuildLuxuryCar(Location.DEFAULT);
            Console.ReadLine();
        }
    }

    #region Enums
    public enum CarType
    {
        MICRO, MINI, LUXURY
    }
    public enum Location
    {
        DEFAULT, INDIA, USA
    }

    #endregion
}
