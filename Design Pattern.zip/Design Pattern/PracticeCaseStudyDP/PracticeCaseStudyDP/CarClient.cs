﻿namespace PracticeCaseStudyDP
{
    public class CarClient
    {
        private CarFactory _carFactory;

        public CarClient(CarFactory carFactory)
        {
            _carFactory = carFactory;
        }

        public void BuildMicroCar(Location location)
        {
            switch (location)
            {
                case Location.DEFAULT:
                    _carFactory = new DefaultCarFactory();
                    _carFactory.BuildCar(CarType.MICRO);
                    break;
                case Location.INDIA:
                    _carFactory = new IndiaCarFactory();
                    _carFactory.BuildCar(CarType.MICRO);
                    break;
                case Location.USA:
                    _carFactory = new USACarFactory();
                    _carFactory.BuildCar(CarType.MICRO);
                    break;
                default:
                    break;
            }
        }
        public void BuildLuxuryCar(Location location)
        {
            switch (location)
            {
                case Location.DEFAULT:
                    _carFactory = new DefaultCarFactory();
                    _carFactory.BuildCar(CarType.LUXURY);
                    break;
                case Location.INDIA:
                    _carFactory = new IndiaCarFactory();
                    _carFactory.BuildCar(CarType.LUXURY);
                    break;
                case Location.USA:
                    _carFactory = new USACarFactory();
                    _carFactory.BuildCar(CarType.LUXURY);
                    break;
                default:
                    break;
            }
        }
        public void BuildMiniCar(Location location)
        {
            switch (location)
            {
                case Location.DEFAULT:
                    _carFactory = new DefaultCarFactory();
                    _carFactory.BuildCar(CarType.MINI);
                    break;
                case Location.INDIA:
                    _carFactory = new IndiaCarFactory();
                    _carFactory.BuildCar(CarType.MINI);
                    break;
                case Location.USA:
                    _carFactory = new USACarFactory();
                    _carFactory.BuildCar(CarType.MINI);
                    break;
                default:
                    break;
            }
        }
    }
}
