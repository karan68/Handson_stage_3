﻿using System;

namespace Facade
{
    interface IShape
    {
        void Draw();
    }
}
