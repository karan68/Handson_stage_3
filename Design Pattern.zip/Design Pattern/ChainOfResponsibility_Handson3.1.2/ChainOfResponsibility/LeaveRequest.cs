﻿using System;

namespace ChainOfResponsibility
{
    class LeaveRequest
    {
        public string Employee { get; set; }

        public int LeaveDays { get; set; }
    }
}
